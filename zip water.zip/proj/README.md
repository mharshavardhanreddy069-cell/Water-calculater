# Water Target Calculator — Android (Java, no third-party libraries)

Implements the full specification: onboarding, personal target formula, weather (Open-Meteo),
break-aware reminders, 5 screens (Today, Breakdown, Schedule, History, Settings), on-device storage only.

## Build the debug APK (for your phone)
1. Install Android Studio (needs JDK 17+, bundled) and open this folder.
2. Let Gradle sync; install Android SDK Platform 35 if asked.
3. **Build → Build Bundle(s) / APK(s) → Build APK(s)**. Click "locate" in the popup.
   Copy `app-debug.apk` to your phone and open it (allow "install unknown apps").

Command line alternative: `gradle assembleDebug` -> app/build/outputs/apk/debug/app-debug.apk

## Play Store (.aab)
1. **Build → Generate Signed Bundle / APK → Android App Bundle**, create a keystore, finish.
   KEEP the keystore and passwords safe; you need them for every update.
2. Or create `keystore.properties` next to settings.gradle:
   storeFile=my.jks / storePassword=... / keyAlias=... / keyPassword=...
   then run `gradle bundleRelease` -> app/build/outputs/bundle/release/app-release.aab
3. Before publishing: change the package id `com.yourname.watertarget` (app/build.gradle + folder + manifest),
   put your email in the store listing, add real-device screenshots, 512px icon and 1024x500 feature graphic.

## Notes
- Formula: weight x 33 ml, x age, x sex, x (1+job), x (1+each extra), x heat, x humidity. Height is shown but not used.
- Reminders: AlarmManager.setExactAndAllowWhileIdle (falls back to inexact if exact alarms are denied),
  re-planned after every alarm, on boot, and when routine/extras/weather change. Max 9/day, breaks snap within 25 min.
  Reminders are skipped once the day's target is reached.
- A foreground service was not added: exact alarms + a broadcast receiver survive Doze without it.
- Weather older than 6 h is not used for the target, and cached weather is always labelled with its age.
- Not medical advice (disclaimer shown in app).
