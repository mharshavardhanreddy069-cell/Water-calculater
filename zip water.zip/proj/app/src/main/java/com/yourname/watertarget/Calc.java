package com.yourname.watertarget;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** Pure logic: water-target formula and reminder planning. No Android dependencies. */
public final class Calc {
    public static final int GLASS_ML = 250;
    public static final int MAX_MOMENTS = 9;
    public static final int BREAK_SNAP_MIN = 25;

    public static final class Step {
        public final String label; public final double deltaMl, totalMl;
        Step(String l, double d, double t) { label = l; deltaMl = d; totalMl = t; }
    }
    public static final class Result {
        public final List<Step> steps = new ArrayList<>();
        public double totalMl; public int glasses;
        public double heatPct;
    }
    public static final class Moment {
        public int minute;       // minutes after midnight of the window's first day (may exceed 1440)
        public int glasses; public boolean breakAnchor;
    }

    private static void add(Result r, String label, double newTotal) {
        double prev = r.steps.isEmpty() ? 0 : r.totalMl;
        r.steps.add(new Step(label, newTotal - prev, newTotal));
        r.totalMl = newTotal;
    }

    /** feelsLikeC / humidityPct may be null when no weather is available. */
    public static Result compute(double weightKg, int age, String sex, String jobLabel, double jobFactor,
                                 List<String> extraLabels, List<Double> extraFactors,
                                 Double feelsLikeC, Double humidityPct) {
        Result r = new Result();
        double t = weightKg * 33.0;
        add(r, "Base (weight × 33 ml)", t);
        double ageM = age < 18 ? 0.94 : (age >= 65 ? 1.06 : 1.0);
        t *= ageM; add(r, "Age", t);
        double sexM = "female".equals(sex) ? 0.92 : ("other".equals(sex) ? 0.96 : 1.0);
        t *= sexM; add(r, "Sex", t);
        t *= (1 + jobFactor); add(r, "Work: " + jobLabel, t);
        for (int i = 0; i < extraLabels.size(); i++) {
            t *= (1 + extraFactors.get(i)); add(r, extraLabels.get(i), t);
        }
        if (feelsLikeC != null) {
            double heat = Math.max(0, Math.min(0.45, (feelsLikeC - 20) * 0.032));
            r.heatPct = heat * 100;
            t *= (1 + heat); add(r, "Heat (feels like " + Math.round(feelsLikeC) + "°C)", t);
        }
        if (humidityPct != null) {
            t *= humidityPct >= 70 ? 1.05 : 1.0; add(r, "Humidity (" + Math.round(humidityPct) + "%)", t);
        }
        r.glasses = Math.max(1, (int) Math.round(t / GLASS_ML));
        return r;
    }

    /**
     * Plan reminder moments inside wake..sleep (crossing midnight if sleep <= wake).
     * Max 9 moments; breaks within 25 min of a generated time replace it; glasses sum exactly.
     */
    public static List<Moment> plan(int wakeMin, int sleepMin, List<Integer> breaks, int glasses) {
        int end = sleepMin <= wakeMin ? sleepMin + 1440 : sleepMin;
        int span = end - wakeMin;
        int n = Math.max(1, Math.min(MAX_MOMENTS, glasses));
        List<Moment> ms = new ArrayList<>();
        for (int i = 0; i < n; i++) {
            Moment m = new Moment();
            m.minute = wakeMin + Math.round((float) span * (i + 1) / (n + 1));
            ms.add(m);
        }
        List<Integer> bs = new ArrayList<>();
        for (int b : breaks) {
            int x = b;
            if (x < wakeMin) x += 1440;
            if (x >= wakeMin && x <= end) bs.add(x);
        }
        Collections.sort(bs);
        for (int b : bs) {
            Moment best = null; int bd = Integer.MAX_VALUE;
            for (Moment m : ms) {
                if (m.breakAnchor) continue;
                int d = Math.abs(m.minute - b);
                if (d < bd) { bd = d; best = m; }
            }
            if (best != null && bd <= BREAK_SNAP_MIN) { best.minute = b; best.breakAnchor = true; }
        }
        Collections.sort(ms, (a, c) -> Integer.compare(a.minute, c.minute));
        int base = glasses / n, rem = glasses % n;
        for (int i = 0; i < n; i++) ms.get(i).glasses = base + (i < rem ? 1 : 0);
        return ms;
    }
}
