package com.yourname.watertarget;

import android.app.AlarmManager;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

/** Local-only reminders using AlarmManager.setExactAndAllowWhileIdle. */
public final class Scheduler {
    static final String CHANNEL = "water_reminders";
    static final int SLOTS = 18;          // today's window (9) + next window (9)
    static final int CODE_BASE = 100, CODE_SNOOZE = 200;
    static final long WEATHER_MAX_AGE = 6 * 3600 * 1000L;

    public static Calc.Result target(Context c, Store s) {
        List<String> el = new ArrayList<>(); List<Double> ef = new ArrayList<>();
        for (int i = 0; i < Store.EXTRA_IDS.length; i++)
            if (s.extra(i)) { el.add(Store.EXTRA_LABELS[i]); ef.add(Store.EXTRA_FACTORS[i]); }
        Store.WeatherData w = s.weather();
        boolean fresh = w != null && System.currentTimeMillis() - w.ts < WEATHER_MAX_AGE;
        int j = s.jobIndex();
        Calc.Result r = Calc.compute(s.weight(), s.age(), s.sex(), Store.JOB_LABELS[j], Store.JOB_FACTORS[j], el, ef,
            fresh ? w.feels : null, fresh ? w.humidity : null);
        s.setTodayTarget(r.glasses);
        return r;
    }

    /** Midnight (local) of the window's first day, in millis. */
    static Calendar windowDay(Store s, long now) {
        Calendar c = Calendar.getInstance();
        c.setTimeInMillis(now);
        c.set(Calendar.HOUR_OF_DAY, 0); c.set(Calendar.MINUTE, 0); c.set(Calendar.SECOND, 0); c.set(Calendar.MILLISECOND, 0);
        if (s.crossesMidnight()) {
            Calendar y = (Calendar) c.clone(); y.add(Calendar.DAY_OF_YEAR, -1);
            if (now < at(y, s.sleep() + 1440)) return y;
        }
        return c;
    }
    static long at(Calendar midnight, int minute) {
        Calendar c = (Calendar) midnight.clone();
        c.set(Calendar.HOUR_OF_DAY, minute / 60); c.set(Calendar.MINUTE, minute % 60);
        return c.getTimeInMillis();
    }

    /** Moments of today's window with glasses and anchors. */
    public static List<Calc.Moment> todayPlan(Context c, Store s) {
        return Calc.plan(s.wake(), s.sleep(), s.breaks(), target(c, s).glasses);
    }

    public static void ensureChannel(Context c) {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationManager nm = c.getSystemService(NotificationManager.class);
            nm.createNotificationChannel(new NotificationChannel(CHANNEL, "Water reminders", NotificationManager.IMPORTANCE_HIGH));
        }
    }

    private static PendingIntent pi(Context c, int code) {
        Intent i = new Intent(c, AlarmReceiver.class);
        return PendingIntent.getBroadcast(c, code, i, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }

    private static void setAlarm(Context c, long when, int code) {
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        PendingIntent p = pi(c, code);
        try {
            if (Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms())
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when, p);
            else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when, p);
        } catch (SecurityException e) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when, p);
        }
    }

    public static void cancelAll(Context c) {
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        for (int i = 0; i < SLOTS; i++) am.cancel(pi(c, CODE_BASE + i));
        am.cancel(pi(c, CODE_SNOOZE));
    }

    public static void snooze(Context c, int minutes) { setAlarm(c, System.currentTimeMillis() + minutes * 60000L, CODE_SNOOZE); }

    /** Re-place all remaining reminders (called on routine/extras/weather change, boot, and after each alarm). */
    public static void reschedule(Context c) {
        Store s = new Store(c);
        cancelAll(c);
        if (!s.onboarded() || !s.remindersOn()) return;
        long now = System.currentTimeMillis();
        List<Calc.Moment> plan = todayPlan(c, s);
        Calendar day = windowDay(s, now);
        for (int d = 0; d < 2; d++) {
            Calendar base = (Calendar) day.clone(); base.add(Calendar.DAY_OF_YEAR, d);
            for (int i = 0; i < plan.size(); i++) {
                long t = at(base, plan.get(i).minute);
                if (t > now + 5000) setAlarm(c, t, CODE_BASE + d * 9 + i);
            }
        }
    }
}
