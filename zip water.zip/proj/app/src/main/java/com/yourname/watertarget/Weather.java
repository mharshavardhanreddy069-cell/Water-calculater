package com.yourname.watertarget;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationManager;
import android.os.Build;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import org.json.JSONArray;
import org.json.JSONObject;

/** Open-Meteo weather + geocoding. Blocking calls: run on a background thread. */
public final class Weather {
    static final String WEATHER = "https://api.open-meteo.com/v1/forecast";
    static final String GEOCODE = "https://geocoding-api.open-meteo.com/v1/search";
    public static final long REFRESH_MS = 20 * 60 * 1000L;

    private static String get(String u) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(u).openConnection();
        c.setConnectTimeout(10000); c.setReadTimeout(10000);
        try (BufferedReader r = new BufferedReader(new InputStreamReader(c.getInputStream()))) {
            StringBuilder sb = new StringBuilder(); String l;
            while ((l = r.readLine()) != null) sb.append(l);
            return sb.toString();
        } finally { c.disconnect(); }
    }

    /** Returns {feelsLikeC, humidityPct}. */
    public static double[] fetch(double lat, double lon) throws Exception {
        String u = WEATHER + "?latitude=" + lat + "&longitude=" + lon
            + "&current=apparent_temperature,relative_humidity_2m&timezone=auto";
        JSONObject cur = new JSONObject(get(u)).getJSONObject("current");
        return new double[]{cur.getDouble("apparent_temperature"), cur.getDouble("relative_humidity_2m")};
    }

    /** Returns {lat, lon} and fills name[0]; null if not found. */
    public static double[] geocode(String city, String[] name) throws Exception {
        JSONObject o = new JSONObject(get(GEOCODE + "?name=" + URLEncoder.encode(city, "UTF-8") + "&count=1&language=en&format=json"));
        JSONArray a = o.optJSONArray("results");
        if (a == null || a.length() == 0) return null;
        JSONObject r = a.getJSONObject(0);
        name[0] = r.optString("name", city);
        return new double[]{r.getDouble("latitude"), r.getDouble("longitude")};
    }

    public static boolean hasLocationPermission(Context c) {
        return c.checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }

    /** Approximate device location, or null. Blocking (up to ~8 s). */
    public static Location device(Context c) {
        if (!hasLocationPermission(c)) return null;
        LocationManager lm = (LocationManager) c.getSystemService(Context.LOCATION_SERVICE);
        if (lm == null) return null;
        Location best = null;
        try {
            for (String p : lm.getProviders(true)) {
                Location l = lm.getLastKnownLocation(p);
                if (l != null && (best == null || l.getTime() > best.getTime())) best = l;
            }
            if (best != null || Build.VERSION.SDK_INT < 30) return best;
            if (!lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) return null;
            final Location[] out = new Location[1];
            final CountDownLatch latch = new CountDownLatch(1);
            lm.getCurrentLocation(LocationManager.NETWORK_PROVIDER, null, Runnable::run, l -> { out[0] = l; latch.countDown(); });
            latch.await(8, TimeUnit.SECONDS);
            return out[0];
        } catch (Exception e) { return best; }
    }
}
