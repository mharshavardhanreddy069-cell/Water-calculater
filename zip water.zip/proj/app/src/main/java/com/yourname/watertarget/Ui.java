package com.yourname.watertarget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.text.InputType;
import android.text.format.DateFormat;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

final class Ui {
    static final int BG = Color.rgb(7, 26, 43), SURFACE = Color.rgb(11, 41, 66), CYAN = Color.rgb(58, 208, 255);
    static final int WHITE = Color.rgb(234, 246, 255), MUTED = Color.rgb(143, 178, 204), GREEN = Color.rgb(110, 231, 183);

    static int dp(Context c, int v) { return (int) (v * c.getResources().getDisplayMetrics().density + 0.5f); }

    static GradientDrawable rounded(Context c, int color, int radiusDp) {
        GradientDrawable g = new GradientDrawable(); g.setColor(color); g.setCornerRadius(dp(c, radiusDp)); return g;
    }
    static TextView text(Context c, String s, int sp, int color, boolean bold) {
        TextView t = new TextView(c); t.setText(s); t.setTextSize(sp); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }
    static LinearLayout column(Context c) {
        LinearLayout l = new LinearLayout(c); l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(c, 18), dp(c, 16), dp(c, 18), dp(c, 16)); return l;
    }
    static LinearLayout card(Context c) {
        LinearLayout l = column(c); l.setBackground(rounded(c, SURFACE, 16)); return l;
    }
    static LinearLayout.LayoutParams lp(Context c, int top, int bottom) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2); p.setMargins(0, dp(c, top), 0, dp(c, bottom)); return p;
    }
    static Button button(Context c, String label, int bg, int fg) {
        Button b = new Button(c); b.setText(label); b.setTextColor(fg); b.setAllCaps(false); b.setTextSize(15);
        b.setBackground(rounded(c, bg, 12)); b.setPadding(dp(c, 12), dp(c, 12), dp(c, 12), dp(c, 12)); return b;
    }
    static EditText input(Context c, String hint, String value, int type) {
        EditText e = new EditText(c); e.setHint(hint); e.setText(value); e.setInputType(type);
        e.setTextColor(WHITE); e.setHintTextColor(MUTED); e.setBackgroundTintList(ColorStateList.valueOf(CYAN)); return e;
    }
    static final int INT = InputType.TYPE_CLASS_NUMBER;
    static final int DEC = InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL;

    static String fmt(Context c, int minute) {
        int m = ((minute % 1440) + 1440) % 1440, h = m / 60, mi = m % 60;
        if (DateFormat.is24HourFormat(c)) return String.format("%02d:%02d", h, mi);
        return String.format("%d:%02d %s", h % 12 == 0 ? 12 : h % 12, mi, h < 12 ? "AM" : "PM");
    }
    static View space(Context c, int h) { View v = new View(c); v.setLayoutParams(new LinearLayout.LayoutParams(1, dp(c, h))); return v; }
}
