package com.yourname.watertarget;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.Icon;

public class AlarmReceiver extends BroadcastReceiver {
    static final int NOTIF_ID = 1;

    @Override public void onReceive(Context c, Intent in) {
        Store s = new Store(c);
        if (s.onboarded() && s.remindersOn()) {
            Calc.Result r = Scheduler.target(c, s);
            int done = s.glasses();
            if (done < r.glasses) post(c, s, done, r.glasses);
        }
        Scheduler.reschedule(c);   // keeps the chain going and re-places the rest
    }

    static void post(Context c, Store s, int done, int total) {
        Scheduler.ensureChannel(c);
        int flags = PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT;
        Intent log = new Intent(c, ActionReceiver.class).setAction(ActionReceiver.LOG);
        Intent snz = new Intent(c, ActionReceiver.class).setAction(ActionReceiver.SNOOZE);
        PendingIntent open = PendingIntent.getActivity(c, 0, new Intent(c, MainActivity.class), flags);
        Icon icon = Icon.createWithResource(c, R.drawable.ic_drop);
        Notification n = new Notification.Builder(c, Scheduler.CHANNEL)
            .setSmallIcon(R.drawable.ic_drop)
            .setContentTitle("Time for water, " + s.name())
            .setContentText(done + " of " + total + " glasses today")
            .setContentIntent(open).setAutoCancel(true)
            .addAction(new Notification.Action.Builder(icon, "Log a glass", PendingIntent.getBroadcast(c, 1, log, flags)).build())
            .addAction(new Notification.Action.Builder(icon, "Snooze 20 min", PendingIntent.getBroadcast(c, 2, snz, flags)).build())
            .build();
        try { c.getSystemService(NotificationManager.class).notify(NOTIF_ID, n); } catch (SecurityException ignored) {}
    }
}
