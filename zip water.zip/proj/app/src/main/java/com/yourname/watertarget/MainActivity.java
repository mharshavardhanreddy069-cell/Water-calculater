package com.yourname.watertarget;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.PowerManager;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class MainActivity extends Activity {
    static final String DISCLAIMER = "This is a general estimate based on body weight, activity and weather. It is not medical advice. "
        + "If you have a heart or kidney condition affecting fluid intake, follow your doctor instead.";
    static final String[] TABS = {"Today", "Breakdown", "Schedule", "History", "Settings"};

    private Store st;
    private FrameLayout content;
    private LinearLayout nav;
    private int tab = 0;
    private boolean refreshing = false;
    private ConnectivityManager.NetworkCallback netCb;

    // flow (onboarding / edit) state
    private int flowFirst, flowLast, flowStep;
    private boolean flowEdit;
    private String fName = "", fSex = "male";
    private int fAge = 30, fHeight = 170, fJob = 2, fWake = 420, fSleep = 1320;
    private float fWeight = 70f;
    private final List<Integer> fBreaks = new ArrayList<>();

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        st = new Store(this);
        if (st.onboarded()) showMain(); else startFlow(0, 4, false);
    }

    @Override protected void onResume() {
        super.onResume();
        if (st.onboarded() && content != null) { render(); refreshWeather(false); }
    }
    @Override protected void onStart() {
        super.onStart();
        ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        netCb = new ConnectivityManager.NetworkCallback() {
            @Override public void onAvailable(Network n) { if (st.onboarded()) runOnUiThread(() -> refreshWeather(false)); }
        };
        try { cm.registerDefaultNetworkCallback(netCb); } catch (Exception ignored) {}
    }
    @Override protected void onStop() {
        super.onStop();
        try { ((ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE)).unregisterNetworkCallback(netCb); } catch (Exception ignored) {}
    }

    // ================= main shell =================
    private void showMain() {
        LinearLayout shell = new LinearLayout(this); shell.setOrientation(LinearLayout.VERTICAL); shell.setBackgroundColor(Ui.BG);
        content = new FrameLayout(this);
        shell.addView(content, new LinearLayout.LayoutParams(-1, 0, 1f));
        nav = new LinearLayout(this); nav.setBackgroundColor(Ui.SURFACE);
        shell.addView(nav, new LinearLayout.LayoutParams(-1, -2));
        setContentView(shell);
        shell.setFitsSystemWindows(true);
        Scheduler.reschedule(this);
        render();
        refreshWeather(false);
    }

    private void render() {
        nav.removeAllViews();
        for (int i = 0; i < TABS.length; i++) {
            final int idx = i;
            TextView t = Ui.text(this, TABS[i], 12, i == tab ? Ui.CYAN : Ui.MUTED, i == tab);
            t.setGravity(Gravity.CENTER); t.setPadding(0, Ui.dp(this, 14), 0, Ui.dp(this, 14));
            t.setOnClickListener(v -> { tab = idx; render(); });
            nav.addView(t, new LinearLayout.LayoutParams(0, -2, 1f));
        }
        LinearLayout page = Ui.column(this);
        ScrollView sv = new ScrollView(this); sv.addView(page);
        content.removeAllViews(); content.addView(sv);
        Calc.Result r = Scheduler.target(this, st);
        switch (tab) {
            case 0: today(page, r); break;
            case 1: breakdown(page, r); break;
            case 2: schedule(page, r); break;
            case 3: history(page); break;
            default: settings(page); break;
        }
        page.addView(Ui.text(this, DISCLAIMER, 11, Ui.MUTED, false), Ui.lp(this, 20, 8));
    }

    private String weatherAge() {
        Store.WeatherData w = st.weather();
        if (w == null) return null;
        long min = (System.currentTimeMillis() - w.ts) / 60000;
        return min < 1 ? "just now" : (min < 60 ? min + " min ago" : (min / 60) + " h ago");
    }

    // ================= Today =================
    private void today(LinearLayout p, Calc.Result r) {
        p.addView(Ui.text(this, "💧  WATER TARGET", 13, Ui.CYAN, true));
        p.addView(Ui.text(this, "Hi, " + st.name(), 26, Ui.WHITE, true));
        int done = st.glasses();
        LinearLayout card = Ui.card(this); p.addView(card, Ui.lp(this, 16, 12));
        card.addView(Ui.text(this, "TODAY'S TARGET", 12, Ui.MUTED, true));
        TextView big = Ui.text(this, r.glasses + " glasses", 38, Ui.WHITE, true); big.setGravity(Gravity.CENTER); card.addView(big);
        TextView lit = Ui.text(this, String.format("%.2f litres", r.totalMl / 1000.0), 16, Ui.CYAN, true); lit.setGravity(Gravity.CENTER); card.addView(lit);
        ProgressBar bar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        bar.setMax(100); bar.setProgress(Math.min(100, done * 100 / r.glasses));
        bar.setProgressTintList(android.content.res.ColorStateList.valueOf(done >= r.glasses ? Ui.GREEN : Ui.CYAN));
        card.addView(bar, new LinearLayout.LayoutParams(-1, Ui.dp(this, 10)));
        TextView prog = Ui.text(this, done + " of " + r.glasses + " glasses  •  " + String.format("%.2f L", done * Calc.GLASS_ML / 1000.0)
            + (done >= r.glasses ? "  ✓ target reached" : ""), 14, done >= r.glasses ? Ui.GREEN : Ui.WHITE, false);
        prog.setGravity(Gravity.CENTER); prog.setPadding(0, Ui.dp(this, 10), 0, 0); card.addView(prog);

        String age = weatherAge();
        Store.WeatherData w = st.weather();
        String stmt;
        if (w == null) stmt = "No weather yet — today's target uses your body and day only." + (st.city().isEmpty() && !Weather.hasLocationPermission(this) ? " Set a city in Settings to include weather." : "");
        else if (System.currentTimeMillis() - w.ts > Scheduler.WEATHER_MAX_AGE) stmt = "Saved weather is too old (" + age + ") so it isn't used. Connect to refresh.";
        else stmt = String.format("Feels like %.0f°C with %.0f%% humidity", w.feels, w.humidity)
            + (r.heatPct > 0 ? String.format(", adding about %.0f%% to your target.", r.heatPct) : ", so no heat adjustment today.")
            + (isLive() ? "  (updated " + age + ")" : "  (saved weather from " + age + " — offline)");
        p.addView(Ui.text(this, stmt, 13, Ui.MUTED, false), Ui.lp(this, 0, 8));

        Button add = Ui.button(this, "+  Log a glass (250 ml)", Ui.CYAN, Ui.BG); p.addView(add, Ui.lp(this, 6, 4));
        add.setOnClickListener(v -> { st.addGlass(); render(); });
        Button undo = Ui.button(this, "Undo last glass", Ui.SURFACE, Ui.WHITE); p.addView(undo, Ui.lp(this, 4, 4));
        undo.setOnClickListener(v -> { st.undoGlass(); render(); });
        Button ref = Ui.button(this, "Refresh weather", Ui.SURFACE, Ui.WHITE); p.addView(ref, Ui.lp(this, 4, 8));
        ref.setOnClickListener(v -> refreshWeather(true));

        p.addView(Ui.text(this, "TODAY'S EXTRAS", 12, Ui.CYAN, true), Ui.lp(this, 10, 2));
        for (int i = 0; i < Store.EXTRA_IDS.length; i++) {
            final int idx = i;
            CheckBox cb = new CheckBox(this);
            cb.setText(Store.EXTRA_LABELS[i] + "  (+" + Math.round(Store.EXTRA_FACTORS[i] * 100) + "%)");
            cb.setTextColor(Ui.WHITE); cb.setChecked(st.extra(i));
            cb.setOnCheckedChangeListener((b, on) -> { st.setExtra(idx, on); Scheduler.reschedule(this); render(); });
            p.addView(cb);
        }
    }
    private boolean lastFetchOk = false;
    private boolean isLive() { Store.WeatherData w = st.weather(); return lastFetchOk && w != null && System.currentTimeMillis() - w.ts < Weather.REFRESH_MS + 60000; }

    // ================= Breakdown =================
    private void breakdown(LinearLayout p, Calc.Result r) {
        p.addView(Ui.text(this, "Breakdown", 26, Ui.WHITE, true));
        p.addView(Ui.text(this, "Every step that makes up today's target.", 13, Ui.MUTED, false), Ui.lp(this, 0, 12));
        for (int i = 0; i < r.steps.size(); i++) {
            Calc.Step s = r.steps.get(i);
            LinearLayout row = Ui.card(this); p.addView(row, Ui.lp(this, 4, 4));
            row.addView(Ui.text(this, s.label, 14, Ui.WHITE, false));
            String d = i == 0 ? String.format("%.2f L", s.deltaMl / 1000) : String.format("%+.2f L", s.deltaMl / 1000);
            TextView v = Ui.text(this, d + "   →   " + String.format("%.2f L", s.totalMl / 1000), 15, s.deltaMl > 0.5 || i == 0 ? Ui.CYAN : Ui.MUTED, true);
            row.addView(v);
        }
        LinearLayout tot = Ui.card(this); p.addView(tot, Ui.lp(this, 10, 4));
        tot.addView(Ui.text(this, "TOTAL", 12, Ui.MUTED, true));
        tot.addView(Ui.text(this, String.format("%.2f L  ≈  %d glasses", r.totalMl / 1000.0, r.glasses), 22, Ui.GREEN, true));
        p.addView(Ui.text(this, "Height (" + st.height() + " cm) is shown on your profile but does not change the target; weight is the real driver.", 12, Ui.MUTED, false), Ui.lp(this, 10, 0));
        if (st.weather() == null) p.addView(Ui.text(this, "Weather steps appear once weather is available.", 12, Ui.MUTED, false), Ui.lp(this, 6, 0));
    }

    // ================= Schedule =================
    private void schedule(LinearLayout p, Calc.Result r) {
        p.addView(Ui.text(this, "Schedule", 26, Ui.WHITE, true));
        p.addView(Ui.text(this, Ui.fmt(this, st.wake()) + " – " + Ui.fmt(this, st.sleep()) + (st.crossesMidnight() ? "  (crosses midnight)" : ""), 13, Ui.MUTED, false), Ui.lp(this, 0, 12));
        if (!st.remindersOn()) { p.addView(Ui.text(this, "Reminders are off. Turn them on in Settings.", 14, Ui.WHITE, false)); return; }
        List<Calc.Moment> ms = Calc.plan(st.wake(), st.sleep(), st.breaks(), r.glasses);
        for (Calc.Moment m : ms) {
            LinearLayout row = Ui.card(this);
            if (m.breakAnchor) row.setBackground(Ui.rounded(this, Color_BREAK, 16));
            p.addView(row, Ui.lp(this, 4, 4));
            row.addView(Ui.text(this, Ui.fmt(this, m.minute) + (m.breakAnchor ? "   ★ break" : ""), 17, m.breakAnchor ? Ui.BG : Ui.WHITE, true));
            row.addView(Ui.text(this, m.glasses + (m.glasses == 1 ? " glass" : " glasses"), 14, m.breakAnchor ? Ui.BG : Ui.CYAN, false));
        }
        p.addView(Ui.text(this, "Up to 9 reminders a day, never outside your waking hours. ★ marks moments snapped to your break times.", 12, Ui.MUTED, false), Ui.lp(this, 10, 0));
    }
    static final int Color_BREAK = Ui.CYAN;

    // ================= History =================
    private void history(LinearLayout p) {
        p.addView(Ui.text(this, "History", 26, Ui.WHITE, true));
        LinearLayout sc = Ui.card(this); p.addView(sc, Ui.lp(this, 10, 10));
        sc.addView(Ui.text(this, "STREAK", 12, Ui.MUTED, true));
        int s = st.streak();
        sc.addView(Ui.text(this, s + (s == 1 ? " day" : " days") + " in a row", 24, Ui.GREEN, true));
        sc.addView(Ui.text(this, "Days you reached your target", 12, Ui.MUTED, false));
        for (int off = 0; off >= -6; off--) {
            String d = st.dayKey(off);
            int g = st.glasses(d), t = st.target(d);
            if (off == 0 && t == 0) t = Scheduler.target(this, st).glasses;
            LinearLayout row = Ui.column(this); row.setPadding(0, Ui.dp(this, 8), 0, 0);
            String label = off == 0 ? "Today" : (off == -1 ? "Yesterday" : d.substring(6, 8) + "/" + d.substring(4, 6));
            row.addView(Ui.text(this, label + "   " + g + (t > 0 ? " / " + t : "") + " glasses", 14, Ui.WHITE, false));
            ProgressBar bar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
            bar.setMax(100); bar.setProgress(t > 0 ? Math.min(100, g * 100 / t) : 0);
            bar.setProgressTintList(android.content.res.ColorStateList.valueOf(t > 0 && g >= t ? Ui.GREEN : Ui.CYAN));
            row.addView(bar, new LinearLayout.LayoutParams(-1, Ui.dp(this, 8)));
            p.addView(row);
        }
    }

    // ================= Settings =================
    private void settings(LinearLayout p) {
        p.addView(Ui.text(this, "Settings", 26, Ui.WHITE, true));
        card(p, "PROFILE", st.name() + " • " + st.age() + " yrs • " + st.weight() + " kg • " + st.height() + " cm • " + st.sex(), "Edit profile", () -> startFlow(0, 1, true));
        card(p, "JOB", Store.JOB_LABELS[st.jobIndex()], "Change job", () -> startFlow(2, 2, true));
        card(p, "HOURS", "Awake " + Ui.fmt(this, st.wake()) + " – " + Ui.fmt(this, st.sleep()) + "\nBreaks: " + breaksText(st.breaks()), "Edit hours", () -> startFlow(3, 3, true));
        String loc = st.useCity() ? st.city() : (Weather.hasLocationPermission(this) ? "Using your approximate location" : "Not set");
        card(p, "CITY / WEATHER", loc, "Set city", this::cityDialog);

        LinearLayout rem = Ui.card(this); p.addView(rem, Ui.lp(this, 6, 6));
        Switch sw = new Switch(this); sw.setText("Reminders"); sw.setTextColor(Ui.WHITE); sw.setChecked(st.remindersOn());
        sw.setOnCheckedChangeListener((b, on) -> { st.setRemindersOn(on); Scheduler.reschedule(this); });
        rem.addView(sw);
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            Button b = Ui.button(this, "Allow notifications", Ui.SURFACE, Ui.WHITE); rem.addView(b);
            b.setBackground(Ui.rounded(this, Ui.BG, 12));
            b.setOnClickListener(v -> requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 2));
        }
        card(p, "PRIVACY", "Everything stays on this device. No account, no ads, no analytics. The only network use is Open-Meteo, which receives your coordinates or city text to return weather.", "Delete my data", this::deleteDialog);
    }
    private String breaksText(List<Integer> b) {
        if (b.isEmpty()) return "none";
        StringBuilder sb = new StringBuilder();
        for (int x : b) { if (sb.length() > 0) sb.append(", "); sb.append(Ui.fmt(this, x)); }
        return sb.toString();
    }
    private void card(LinearLayout p, String title, String body, String btn, Runnable action) {
        LinearLayout c = Ui.card(this); p.addView(c, Ui.lp(this, 6, 6));
        c.addView(Ui.text(this, title, 12, Ui.MUTED, true));
        c.addView(Ui.text(this, body, 14, Ui.WHITE, false));
        Button b = Ui.button(this, btn, Ui.BG, Ui.CYAN); c.addView(b, Ui.lp(this, 8, 0));
        b.setOnClickListener(v -> action.run());
    }
    private void cityDialog() {
        EditText in = Ui.input(this, "City, e.g. Mumbai", st.city(), android.text.InputType.TYPE_CLASS_TEXT);
        new AlertDialog.Builder(this).setTitle("Weather location").setView(in)
            .setNegativeButton("Cancel", null)
            .setNeutralButton("Use my location", (d, w) -> {
                st.clearCity();
                if (!Weather.hasLocationPermission(this)) requestPermissions(new String[]{Manifest.permission.ACCESS_COARSE_LOCATION}, 1);
                else refreshWeather(true);
                render();
            })
            .setPositiveButton("Save", (d, w) -> {
                final String q = in.getText().toString().trim();
                if (q.isEmpty()) return;
                new Thread(() -> {
                    try {
                        String[] nm = new String[1];
                        double[] ll = Weather.geocode(q, nm);
                        runOnUiThread(() -> {
                            if (ll == null) { Toast.makeText(this, "City not found", Toast.LENGTH_LONG).show(); return; }
                            st.saveCity(nm[0], ll[0], ll[1]); refreshWeather(true); render();
                        });
                    } catch (Exception e) { runOnUiThread(() -> Toast.makeText(this, "Couldn't look up that city (offline?)", Toast.LENGTH_LONG).show()); }
                }).start();
            }).show();
    }
    private void deleteDialog() {
        new AlertDialog.Builder(this).setTitle("Delete my data?")
            .setMessage("This erases your profile, routine, weather and drink log from this device and cancels reminders.")
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Delete", (d, w) -> {
                Scheduler.cancelAll(this); st.clearAll(); fBreaks.clear(); fName = ""; startFlow(0, 4, false);
            }).show();
    }

    // ================= weather refresh =================
    private void refreshWeather(final boolean manual) {
        if (refreshing) return;
        Store.WeatherData old = st.weather();
        if (!manual && old != null && lastFetchOk && System.currentTimeMillis() - old.ts < Weather.REFRESH_MS) return;
        refreshing = true;
        new Thread(() -> {
            boolean ok = false; String err = null;
            try {
                double lat, lon; boolean have = false;
                lat = 0; lon = 0;
                if (st.useCity()) { lat = st.cityLat(); lon = st.cityLon(); have = true; }
                else {
                    Location l = Weather.device(this);
                    if (l != null) { lat = l.getLatitude(); lon = l.getLongitude(); have = true; }
                }
                if (have) { double[] w = Weather.fetch(lat, lon); st.saveWeather(w[0], w[1]); ok = true; }
                else err = "No location. Set a city in Settings.";
            } catch (Exception e) { err = "Offline — using last saved weather."; }
            final boolean fok = ok; final String ferr = err;
            runOnUiThread(() -> {
                refreshing = false; lastFetchOk = fok;
                if (fok) Scheduler.reschedule(this);
                if (!fok && manual && ferr != null) Toast.makeText(this, ferr, Toast.LENGTH_LONG).show();
                if (st.onboarded() && content != null) render();
            });
        }).start();
    }

    // ================= onboarding / edit flow =================
    private void startFlow(int first, int last, boolean edit) {
        flowFirst = first; flowLast = last; flowEdit = edit;
        fName = st.name(); fAge = st.age(); fWeight = st.weight(); fHeight = st.height(); fSex = st.sex();
        fJob = st.jobIndex(); fWake = st.wake(); fSleep = st.sleep();
        fBreaks.clear(); fBreaks.addAll(st.breaks());
        showStep(first);
    }

    private LinearLayout flowPage(String question) {
        LinearLayout page = Ui.column(this); page.setBackgroundColor(Ui.BG);
        ScrollView sv = new ScrollView(this); sv.setBackgroundColor(Ui.BG); sv.setFillViewport(true); sv.addView(page);
        sv.setFitsSystemWindows(true);
        setContentView(sv); content = null;
        page.addView(Ui.text(this, "💧  WATER TARGET", 13, Ui.CYAN, true));
        if (!flowEdit) page.addView(Ui.text(this, "Step " + (flowStep + 1) + " of 5", 12, Ui.MUTED, false));
        page.addView(Ui.text(this, question, 24, Ui.WHITE, true), Ui.lp(this, 10, 14));
        return page;
    }
    private void nextButton(LinearLayout page, String label, Runnable validateAndSave) {
        Button next = Ui.button(this, label, Ui.CYAN, Ui.BG); page.addView(next, Ui.lp(this, 20, 4));
        next.setOnClickListener(v -> validateAndSave.run());
        if (flowEdit || flowStep > flowFirst) {
            Button back = Ui.button(this, flowStep > flowFirst ? "Back" : "Cancel", Ui.SURFACE, Ui.WHITE); page.addView(back, Ui.lp(this, 4, 4));
            back.setOnClickListener(v -> { if (flowStep > flowFirst) showStep(flowStep - 1); else { showMain(); } });
        }
    }
    private void advance() {
        if (flowStep >= flowLast) finishFlow(); else showStep(flowStep + 1);
    }
    private void finishFlow() {
        st.saveProfile(fName, fAge, fWeight, fHeight, fSex);
        st.saveJob(fJob); st.saveHours(fWake, fSleep, fBreaks);
        st.setOnboarded(true);
        showMain();
    }
    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_SHORT).show(); }

    private void showStep(int i) {
        flowStep = i;
        switch (i) {
            case 0: stepName(); break;
            case 1: stepBody(); break;
            case 2: stepJob(); break;
            case 3: stepHours(); break;
            default: stepPermissions(); break;
        }
    }

    private void stepName() {
        LinearLayout p = flowPage("What should I call you?");
        final EditText e = Ui.input(this, "Your name", fName, android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_FLAG_CAP_WORDS);
        p.addView(e);
        nextButton(p, flowLast == 0 ? "Save" : "Next", () -> {
            String n = e.getText().toString().trim();
            if (n.isEmpty()) { toast("Please enter a name"); return; }
            fName = n; advance();
        });
    }

    private void stepBody() {
        LinearLayout p = flowPage("A few numbers so the target is right");
        final EditText age = Ui.input(this, "Age (years, 10–100)", String.valueOf(fAge), Ui.INT);
        final EditText wt = Ui.input(this, "Weight (kg, 25–250)", String.valueOf(fWeight), Ui.DEC);
        final EditText ht = Ui.input(this, "Height (cm, 100–230)", String.valueOf(fHeight), Ui.INT);
        p.addView(Ui.text(this, "Age", 12, Ui.MUTED, true)); p.addView(age);
        p.addView(Ui.text(this, "Weight (kg)", 12, Ui.MUTED, true)); p.addView(wt);
        p.addView(Ui.text(this, "Height (cm)", 12, Ui.MUTED, true)); p.addView(ht);
        p.addView(Ui.text(this, "Sex", 12, Ui.MUTED, true), Ui.lp(this, 10, 0));
        final RadioGroup rg = new RadioGroup(this);
        for (int i = 0; i < Store.SEXES.length; i++) {
            RadioButton rb = new RadioButton(this); rb.setId(1000 + i); rb.setText(Store.SEXES[i]); rb.setTextColor(Ui.WHITE);
            rg.addView(rb); if (Store.SEXES[i].equals(fSex)) rb.setChecked(true);
        }
        p.addView(rg);
        nextButton(p, flowLast == 1 ? "Save" : "Next", () -> {
            try {
                int a = Integer.parseInt(age.getText().toString().trim());
                float w = Float.parseFloat(wt.getText().toString().trim());
                int h = Integer.parseInt(ht.getText().toString().trim());
                if (a < 10 || a > 100) { toast("Age must be 10–100"); return; }
                if (w < 25 || w > 250) { toast("Weight must be 25–250 kg"); return; }
                if (h < 100 || h > 230) { toast("Height must be 100–230 cm"); return; }
                fAge = a; fWeight = w; fHeight = h;
                int id = rg.getCheckedRadioButtonId(); fSex = Store.SEXES[id >= 1000 ? id - 1000 : 0];
                advance();
            } catch (Exception ex) { toast("Please fill in all numbers"); }
        });
    }

    private void stepJob() {
        LinearLayout p = flowPage("What does your day look like?");
        final RadioGroup rg = new RadioGroup(this);
        for (int i = 0; i < Store.JOB_IDS.length; i++) {
            RadioButton rb = new RadioButton(this); rb.setId(2000 + i); rb.setText(Store.JOB_LABELS[i]); rb.setTextColor(Ui.WHITE); rb.setTextSize(16);
            rb.setPadding(Ui.dp(this, 6), Ui.dp(this, 8), 0, Ui.dp(this, 8));
            rg.addView(rb); if (i == fJob) rb.setChecked(true);
        }
        p.addView(rg);
        nextButton(p, flowLast == 2 ? "Save" : "Next", () -> {
            int id = rg.getCheckedRadioButtonId(); fJob = id >= 2000 ? id - 2000 : 2;
            // night shift: suggest a night routine if the hours are still the daytime defaults
            if (Store.JOB_IDS[fJob].equals("nights") && !flowEdit && fWake == 420 && fSleep == 1320) { fWake = 20 * 60; fSleep = 8 * 60; }
            advance();
        });
    }

    private void stepHours() {
        final LinearLayout p = flowPage("When are you awake, and when do you take breaks?");
        final Button wake = Ui.button(this, "Wake up: " + Ui.fmt(this, fWake), Ui.SURFACE, Ui.WHITE);
        final Button sleep = Ui.button(this, "Bedtime: " + Ui.fmt(this, fSleep), Ui.SURFACE, Ui.WHITE);
        p.addView(wake, Ui.lp(this, 4, 4)); p.addView(sleep, Ui.lp(this, 4, 4));
        wake.setOnClickListener(v -> new TimePickerDialog(this, (tp, h, m) -> { fWake = h * 60 + m; wake.setText("Wake up: " + Ui.fmt(this, fWake)); },
            fWake / 60, fWake % 60, android.text.format.DateFormat.is24HourFormat(this)).show());
        sleep.setOnClickListener(v -> new TimePickerDialog(this, (tp, h, m) -> { fSleep = h * 60 + m; sleep.setText("Bedtime: " + Ui.fmt(this, fSleep)); },
            fSleep / 60, fSleep % 60, android.text.format.DateFormat.is24HourFormat(this)).show());
        p.addView(Ui.text(this, "If bedtime is earlier than wake-up, I'll treat it as a night shift and run your window across midnight.", 12, Ui.MUTED, false));
        p.addView(Ui.text(this, "Break times (optional, up to 3). Tap one to remove it.", 13, Ui.WHITE, false), Ui.lp(this, 14, 4));
        final LinearLayout list = new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL); p.addView(list);
        final Button addBreak = Ui.button(this, "+ Add a break time", Ui.BG, Ui.CYAN);
        final Runnable[] redraw = new Runnable[1];
        redraw[0] = () -> {
            list.removeAllViews();
            for (final int b : new ArrayList<>(fBreaks)) {
                Button x = Ui.button(this, Ui.fmt(this, b) + "   ✕", Ui.SURFACE, Ui.WHITE); list.addView(x, Ui.lp(this, 2, 2));
                x.setOnClickListener(v -> { fBreaks.remove(Integer.valueOf(b)); redraw[0].run(); });
            }
            addBreak.setVisibility(fBreaks.size() >= 3 ? View.GONE : View.VISIBLE);
        };
        p.addView(addBreak, Ui.lp(this, 4, 4));
        addBreak.setOnClickListener(v -> new TimePickerDialog(this, (tp, h, m) -> {
            int t = h * 60 + m; if (!fBreaks.contains(t)) fBreaks.add(t); Collections.sort(fBreaks); redraw[0].run();
        }, 13, 0, android.text.format.DateFormat.is24HourFormat(this)).show());
        redraw[0].run();
        nextButton(p, flowLast == 3 ? "Save" : "Next", this::advance);
    }

    private void stepPermissions() {
        LinearLayout p = flowPage("Two permissions, asked once, with a reason for each");
        permRow(p, "Location (approximate)", "To read today's weather where you are. You can skip this and enter a city instead.", "Allow location",
            () -> requestPermissions(new String[]{Manifest.permission.ACCESS_COARSE_LOCATION}, 1));
        permRow(p, "Notifications", "So your water reminders can reach you.", "Allow notifications", () -> {
            if (Build.VERSION.SDK_INT >= 33) requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 2);
            else toast("Notifications are already allowed");
        });
        permRow(p, "Battery saver exemption", "So reminders still fire in battery saver mode.", "Allow", () -> {
            try {
                PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
                if (pm.isIgnoringBatteryOptimizations(getPackageName())) { toast("Already allowed"); return; }
                startActivity(new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:" + getPackageName())));
            } catch (Exception e) { toast("Not available on this device"); }
        });
        p.addView(Ui.text(this, DISCLAIMER, 11, Ui.MUTED, false), Ui.lp(this, 14, 0));
        nextButton(p, "Finish", () -> {
            finishFlow();
            Scheduler.reschedule(this);
            refreshWeather(true);
        });
    }
    private void permRow(LinearLayout p, String title, String reason, String btn, Runnable r) {
        LinearLayout c = Ui.card(this); p.addView(c, Ui.lp(this, 6, 6));
        c.addView(Ui.text(this, title, 15, Ui.WHITE, true)); c.addView(Ui.text(this, reason, 13, Ui.MUTED, false));
        Button b = Ui.button(this, btn, Ui.BG, Ui.CYAN); c.addView(b, Ui.lp(this, 8, 0)); b.setOnClickListener(v -> r.run());
    }

    @Override public void onRequestPermissionsResult(int code, String[] perms, int[] res) {
        super.onRequestPermissionsResult(code, perms, res);
        boolean ok = res.length > 0 && res[0] == PackageManager.PERMISSION_GRANTED;
        if (code == 1) { if (ok && st.onboarded()) refreshWeather(true); else if (!ok) toast("No problem — you can enter a city in Settings"); }
        if (code == 2 && ok) Scheduler.reschedule(this);
    }
}
