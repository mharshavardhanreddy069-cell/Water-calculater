package com.yourname.watertarget;

import android.content.Context;
import android.content.SharedPreferences;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

/** All data lives in on-device SharedPreferences. Nothing is sent anywhere except weather lookups. */
public final class Store {
    public static final String[] JOB_IDS = {"student","farmer","office","driver","home","athlete","medical","nights"};
    public static final String[] JOB_LABELS = {"Student","Farmer / outdoor work","Office / desk job","Driver",
        "At home / housework","Athlete in training","Healthcare / on my feet","Night shift"};
    public static final double[] JOB_FACTORS = {0.04,0.22,0.02,0.08,0.10,0.28,0.14,0.06};
    public static final String[] EXTRA_IDS = {"gym","sun","walk","sweat"};
    public static final String[] EXTRA_LABELS = {"Gym or sport","Long time outdoors","Long walk or cycle","Heavy sweaty work"};
    public static final double[] EXTRA_FACTORS = {0.08,0.06,0.04,0.12};
    public static final String[] SEXES = {"male","female","other"};

    public static final class WeatherData { public double feels, humidity; public long ts; }

    private final SharedPreferences p;
    public Store(Context c) { p = c.getApplicationContext().getSharedPreferences("water_local", Context.MODE_PRIVATE); }

    public boolean onboarded() { return p.getBoolean("onboarded", false); }
    public void setOnboarded(boolean b) { p.edit().putBoolean("onboarded", b).apply(); }
    public String name() { return p.getString("name", ""); }
    public int age() { return p.getInt("age", 30); }
    public float weight() { return p.getFloat("weight", 70f); }
    public int height() { return p.getInt("height", 170); }
    public String sex() { return p.getString("sex", "male"); }
    public int jobIndex() { return p.getInt("job", 2); }
    public int wake() { return p.getInt("wake", 7 * 60); }
    public int sleep() { return p.getInt("sleep", 22 * 60); }
    public boolean crossesMidnight() { return sleep() <= wake(); }
    public boolean remindersOn() { return p.getBoolean("reminders", true); }
    public void setRemindersOn(boolean b) { p.edit().putBoolean("reminders", b).apply(); }

    public void saveProfile(String name, int age, float weight, int height, String sex) {
        p.edit().putString("name", name).putInt("age", age).putFloat("weight", weight)
            .putInt("height", height).putString("sex", sex).apply();
    }
    public void saveJob(int idx) { p.edit().putInt("job", idx).apply(); }
    public void saveHours(int wake, int sleep, List<Integer> breaks) {
        StringBuilder sb = new StringBuilder();
        for (int b : breaks) { if (sb.length() > 0) sb.append(','); sb.append(b); }
        p.edit().putInt("wake", wake).putInt("sleep", sleep).putString("breaks", sb.toString()).apply();
    }
    public List<Integer> breaks() {
        List<Integer> l = new ArrayList<>();
        String s = p.getString("breaks", "");
        if (s.isEmpty()) return l;
        for (String x : s.split(",")) try { l.add(Integer.parseInt(x)); } catch (Exception ignored) {}
        return l;
    }

    // ---- day key (a night shift's after-midnight hours still belong to the day the shift started) ----
    public String dayKey() { return dayKey(0); }
    public String dayKey(int offsetDays) {
        Calendar c = Calendar.getInstance();
        int mod = c.get(Calendar.HOUR_OF_DAY) * 60 + c.get(Calendar.MINUTE);
        if (crossesMidnight() && mod < sleep()) c.add(Calendar.DAY_OF_YEAR, -1);
        c.add(Calendar.DAY_OF_YEAR, offsetDays);
        return new SimpleDateFormat("yyyyMMdd", Locale.US).format(c.getTime());
    }

    // ---- today's extras ----
    public boolean extra(int i) {
        if (!dayKey().equals(p.getString("extras_day", ""))) return false;
        return p.getBoolean("extra_" + i, false);
    }
    public void setExtra(int i, boolean on) {
        SharedPreferences.Editor e = p.edit();
        if (!dayKey().equals(p.getString("extras_day", ""))) {
            for (int k = 0; k < EXTRA_IDS.length; k++) e.putBoolean("extra_" + k, false);
            e.putString("extras_day", dayKey());
        }
        e.putBoolean("extra_" + i, on).apply();
    }

    // ---- drink log ----
    public int glasses() { return glasses(dayKey()); }
    public int glasses(String day) { return p.getInt("g_" + day, 0); }
    public int target(String day) { return p.getInt("t_" + day, 0); }
    public void setTodayTarget(int g) { p.edit().putInt("t_" + dayKey(), g).apply(); }
    public void addGlass() { p.edit().putInt("g_" + dayKey(), glasses() + 1).apply(); }
    public void undoGlass() { if (glasses() > 0) p.edit().putInt("g_" + dayKey(), glasses() - 1).apply(); }
    public void resetToday() { p.edit().putInt("g_" + dayKey(), 0).apply(); }
    public int streak() {
        int s = 0, off = 0;
        String today = dayKey(0);
        if (!(target(today) > 0 && glasses(today) >= target(today))) off = -1;
        while (off > -400) {
            String d = dayKey(off);
            if (target(d) > 0 && glasses(d) >= target(d)) { s++; off--; } else break;
        }
        return s;
    }

    // ---- location / weather ----
    public String city() { return p.getString("city", ""); }
    public boolean useCity() { return p.getBoolean("use_city", false); }
    public double cityLat() { return Double.longBitsToDouble(p.getLong("city_lat", 0)); }
    public double cityLon() { return Double.longBitsToDouble(p.getLong("city_lon", 0)); }
    public void saveCity(String name, double lat, double lon) {
        p.edit().putString("city", name).putBoolean("use_city", true)
            .putLong("city_lat", Double.doubleToLongBits(lat)).putLong("city_lon", Double.doubleToLongBits(lon)).apply();
    }
    public void clearCity() { p.edit().remove("city").putBoolean("use_city", false).apply(); }
    public void saveWeather(double feels, double hum) {
        p.edit().putFloat("w_feels", (float) feels).putFloat("w_hum", (float) hum).putLong("w_ts", System.currentTimeMillis()).apply();
    }
    public WeatherData weather() {
        long ts = p.getLong("w_ts", 0);
        if (ts == 0) return null;
        WeatherData w = new WeatherData();
        w.feels = p.getFloat("w_feels", 20f); w.humidity = p.getFloat("w_hum", 50f); w.ts = ts;
        return w;
    }

    public void clearAll() { p.edit().clear().apply(); }
}
