package com.yourname.watertarget;

import android.app.NotificationManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class ActionReceiver extends BroadcastReceiver {
    static final String LOG = "com.yourname.watertarget.LOG", SNOOZE = "com.yourname.watertarget.SNOOZE";
    @Override public void onReceive(Context c, Intent in) {
        Store s = new Store(c);
        if (LOG.equals(in.getAction())) s.addGlass();
        else if (SNOOZE.equals(in.getAction())) Scheduler.snooze(c, 20);
        c.getSystemService(NotificationManager.class).cancel(AlarmReceiver.NOTIF_ID);
    }
}
